package assignment4;
import java.util.*;
import java.io.*;

/** 
 * @author Christian Leonard 
 * Assignment 1. 
 *  
 * This program holds Employee information and tracks their attendance.  
 * @since January 26, 2023. 
 * I have followed the UNCG Academic Integrity policy on this assignment. 
 */ 
public class Assignment4 {
    
    static Scanner input = new Scanner(System.in);
    static HashMap<Integer, Employee> employees = new HashMap<>();
    
    public static void main(String[] args) {
        
        attendance();
        menu();    
    }
    
    public static void attendance()
    {
        //reads employee info from "employee.txt" file
        try
        {
            BufferedReader fileReader = new BufferedReader(new FileReader(new File("employee.txt")));
            String line;
            double empSalary = 0.0;
            while((line = fileReader.readLine()) != null)
            {
                String[] empInfo = line.split(",");
                empInfo[1].replaceAll(" ", "");
                empInfo[2].replaceAll(" ", "");
                empSalary = salaryToDouble(empInfo[3]);
                
                Employee employee = new Employee(empInfo[0], empInfo[1], empInfo[2], empSalary);
                
                int empID = idToInt(empInfo[0]);
                
                if(!employees.containsKey(empID)) //checks if employee id is already in the HashMap
                {
                    employees.put(empID, employee);
                }
            }
            fileReader.close();
        }
        
        catch(FileNotFoundException e)
        {
            System.out.println("File \"employee.txt\" not found");
            System.exit(0);
        }
        
        catch(IOException e)
        {
            System.out.println("IOException");
            System.exit(0);
        }
    }
    
    public static void menu()
    {
        System.out.println("\n\n\tMenu\n\n1. Display\n\n2. Add employee\n\n3. Search\n\n4. Remove employee\n\n0. Exit\n");
        int selection = input.nextInt();
        if(selection < 0 && selection > 4)
        {
            throw new IllegalArgumentException("Invalid Selection");
        }
        
        switch(selection)
        {
            case 0:
            {
                System.exit(0);
                break;
            }
            
            case 1:
            {
                display();
                break;
            }
            
            case 2:
            {
                addEmployee();
                break;
            }
            
            case 3:
            {
                System.out.println("\n\nEnter the ID for the employee you want to search for:  ");
                String blank = input.nextLine();
                Employee found = search(input.nextLine());
                if (found != null)
                {
                    System.out.println(found);
                }
                else
                {
                    System.out.println("Invalid ID");
                }
                break;
            }
            
            case 4:
            {
                System.out.println("\n\nEnter the ID for the employee you want to delete:  ");
                String blank = input.nextLine();
                String deleteID = input.nextLine();
                remove(deleteID);
                break;
            }
        }
        
        menu();
    }
    
    public static int idToInt(String id)
    {
        int val = 0;
        try
        {
            val = Integer.parseInt(id);
        }
        
        catch(NumberFormatException e)
        {
            System.out.println("Invalid ID");
        }
        
        return val;
    }
    
    public static double salaryToDouble(String salary)
    {
        double val = 0.0;
        try
        {
            val = Double.parseDouble(salary);
        }
        
        catch(NumberFormatException e)
        {
            System.out.println("Invalid ID");
        }
        
        return val;
    }
    
    public static void display()
    {
        for(Map.Entry<Integer, Employee> e: employees.entrySet())
        {
            System.out.println(e.getValue().toString());
        }
    }
    
    public static Employee search(String id)
    {
        return employees.get(idToInt(id));   
    }
    
    public static void remove(String id)
    {
        File file = new File("employee.txt");
        try{
            if(file.exists() == false)
            {
                System.out.println("\nFile not found\n");
                System.exit(-1);
            }
            if(!employees.containsKey(idToInt(id)))
            {
                System.out.println("Invalid ID");
                return;
            }
            PrintWriter write = new PrintWriter(new FileWriter(file));
            Integer[] array = employees.keySet().toArray(new Integer[0]);
  
            for(int i = 0; i < array.length; i++)
            {
                if(array[i] != idToInt(id))
                {
                    write.append(employees.get(array[i]).getEmployeeID() + ", " + employees.get(array[i]).getFirstName() + ", " + employees.get(array[i]).getLastName() + ", " + employees.get(array[i]).getSalary() + "\n");
                }
            }
            write.close();
            System.out.println("\n" + employees.get(idToInt(id)).getFirstName() + " " + employees.get(idToInt(id)).getLastName()+ " employee has been deleted.");
            employees.remove(idToInt(id));
        }
        
        catch(IOException e)
        {
            System.out.println("\nIOException\n");
        }
    }
    
    public static void addEmployee()
    {
        System.out.println("\n\nEnter the ID number for the employee:  ");
        String blank = input.nextLine();
        String empIDString = input.nextLine();
        System.out.println("\nEnter the first name of the employee:  ");
        String firstName = input.nextLine();
        System.out.println("\nEnter the last name of the employee:  ");
        String lastName = input.nextLine();
        System.out.println("\nEnter the salary for the employee:  $");
        double salary = input.nextDouble();
        blank = input.nextLine();
        
        Employee employee = new Employee(empIDString, firstName, lastName, salary);
                
        int empID = idToInt(empIDString);
                
        if(!employees.containsKey(empID)) //checks if employee id is already in the HashMap
        {
            employees.put(empID, employee);
        }
        
        File file = new File("employee.txt");
        try{
            if(file.exists() == false)
            {
                System.out.println("\nFile not found\n");
                System.exit(-1);
            }
            
            PrintWriter write = new PrintWriter(new FileWriter(file, true));
            write.append("\n" + empIDString + ", " + firstName + ", " + lastName + ", " + salary);
            write.close();
        }
        
        catch(IOException e)
        {
            System.out.println("\nIOException\n");
        }
    }
}
